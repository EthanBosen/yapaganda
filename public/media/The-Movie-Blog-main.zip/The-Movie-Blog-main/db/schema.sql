DROP DATABASE IF EXISTS the_movie_blog;

CREATE DATABASE the_movie_blog;