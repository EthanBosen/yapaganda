const Memory = require('./Memory');
const User = require('./user');
const Comments = require('./comments');



module.exports = { Memory , User, Comments };
